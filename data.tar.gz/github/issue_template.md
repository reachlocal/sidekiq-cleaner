Ruby version:
Sidekiq / Pro / Enterprise version(s):

Please include your initializer and any error message with the full backtrace.

Are you using an old version?
Have you checked the changelogs to see if your issue has been fixed in a later version?

https://github.com/mperham/sidekiq/blob/master/Changes.md
https://github.com/mperham/sidekiq/blob/master/Pro-Changes.md
https://github.com/mperham/sidekiq/blob/master/Ent-Changes.md

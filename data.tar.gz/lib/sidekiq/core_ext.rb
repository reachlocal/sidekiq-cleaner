raise "no longer used, will be removed in 5.1"

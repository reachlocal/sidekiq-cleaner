# frozen_string_literal: true
module Sidekiq
  VERSION = "5.3.8"
end
